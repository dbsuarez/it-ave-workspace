# Slack Lists — Research, Step-by-Step Guide, Interactive Prototype & Implementation Handoff

**Research date:** 2026-11-12  
**Purpose:** Reproduce the useful *functional patterns* of Slack Lists in a separate application without copying Slack's branding or proprietary visual assets.  
**Companion prototype:** [`Slack_Lists_Interactive_Demo.html`](Slack_Lists_Interactive_Demo.html) — open in a browser to interact with the example.

> **Important:** Markdown is a static document format. A standard Markdown viewer (including GitHub) will **not execute** embedded JavaScript or provide live editing widgets. Section 5 documents the interactive prototype in Markdown, while the companion HTML file contains a working interactive implementation. Both files should be kept together.

## 1. Executive summary

Slack Lists combines customizable record tables with Kanban-style boards, subtasks, task discussions, assignment, reusable views, permissions, and workflows. It is especially useful for light project tracking and request intake in a collaborative workspace. The most reusable design pattern is **lists + typed custom fields + field values + items + views**. Build the data model independently of any particular list template.

Our demo is an **IT Support Requests** list; the same engine should support asset inventories, onboarding, license tracking, projects, and change requests.

**Evidence:** [Slack: Use lists](https://slack.com/help/articles/27452748828179-Use-Lists-in-Slack); [Slack: Track project tasks](https://slack.com/help/articles/27588021944339-Slack-lists--Track-project-tasks).

## 2. Official tutorials and references

| Source | Coverage |
|---|---|
| [Use lists in Slack](https://slack.com/help/articles/27452748828179-Use-Lists-in-Slack) | Components, creation, templates, CSV, items/subtasks, message conversion, views |
| [Slack lists: Track project tasks](https://slack.com/help/articles/27588021944339-Slack-lists--Track-project-tasks) | Concrete end-to-end tutorial for fields, tasks, views, sharing, comments, notifications |
| [Set up automations for lists](https://slack.com/help/articles/37752114318227-Set-up-automations-for-lists-in-Slack) | Intake forms, field-change notifications, due-date reminders/summaries |
| [Slack lists: Collect and triage requests](https://slack.com/help/articles/27655266116627-Slack-lists--Collect-and-triage-requests) | Request intake and prioritization workflow |
| [Discover ways to use lists](https://slack.com/help/articles/29269916669331-Discover-ways-to-use-lists-in-Slack) | Workflow examples and use cases |

*Availability note:* Slack says list automations are available on paid plans; verify other plan restrictions against Slack's current documentation before making parity claims. Steps may change as its UI evolves.

## 3. Slack Lists: documented features and proposed priorities

| Capability | Documented Slack behavior | Priority for clone |
|---|---|---|
| Create list | Blank list or template | P0 |
| Items | Editable row-like records | P0 |
| Typed custom fields | Create, edit, delete fields; e.g. text/select/checkbox | P0 |
| Subtasks | Nested tasks with same fields, individual due dates/assignees | P0 |
| Table | Rows for items, columns for fields | P0 |
| Board | Group items by a selected field; move between columns | P0 |
| Filters/sort/group/hide | Modify presentation of records | P0 |
| Saved views | Named combinations of layout and filters; defaults supported | P1 |
| Assignees | Assign users; assigned tasks appear in their list | P1 |
| Item threads | Per-item discussions with mentions | P1 |
| Share/permissions | Share with people or channels; view/edit grants | P1 |
| Item notifications | Subscribe to changes and see notifications in Activity | P1 |
| Message-to-list | Turn a message into a list item | P1 (only with integrated chat) |
| Forms | Publish form that creates items in list | P2 |
| Workflows | Field-change notifications, due-date reminders and summaries | P2 |
| CSV | Import/export list data | P2 |
| History/archive | Version/activity and lifecycle controls | P2 — validate exact behavior separately |

P0/P1/P2 are **our suggested build sequence**, not Slack's categories. Do not assume every suggested extension is implemented by Slack.

## 4. How Slack Lists works — step-by-step

These steps are based primarily on Slack's desktop documentation. Navigation labels may vary by release.

### A. Create list
1. Open **Files** in the desktop sidebar, then **Lists**.
2. Choose **New / New list** (or the create-list control in Files), or start from a **template**.
3. Give the list a title; where offered, choose an emoji and description.
4. Example list: **IT Support Requests**.

### B. Customize fields
1. In the list's header row, select the **+** at the end of the columns.
2. Enter a field name, select a data type, configure options, then **Save**.
3. Suggested fields: **Request**, **Status**, **Priority**, **Assignee**, **Due Date**, **Category**.
4. Hover a field heading to access **Edit field** or **Delete field**.

### C. Add, edit, and break down items
1. Select **Add item**; enter a title or description.
2. Click each cell to populate fields such as status, assignee, and due date.
3. Open an item and select **Add Subtask** to break a request into smaller actions.
4. Each subtask may have its own assignee and due date.
5. When integrated with chat, use a message's **… > Add to list** to turn a message into a record.

### D. Create views
1. Select the filter control from **All items**.
2. Choose **Table** or **Board** layout.
3. Configure filters, sort, group, and hidden fields.
4. Select **Save as new view**, then name the view.
5. Switch views from **All items**; default views can be configured.

### E. Share and collaborate
1. Select **Share** in the list header.
2. Choose people or channels; set **Can view** or **Can edit** as appropriate.
3. Set assignees through the **Assignee** field.
4. Hover over an item and select **Add comment** / **View comment** to work in its own thread.
5. Open the item and configure notifications if required.

### F. Connect workflows
1. Select **Workflows** from the list.
2. For request intake, choose **Form > Set Up**, choose included fields, and **Publish Workflow**.
3. For field updates, select a field header and **Notify when field changes**, choose recipient, and publish.
4. For deadlines, select **Due date notifications > Set Up** to choose a schedule and due-date window.
5. Optionally configure **Due date summary** to publish a scheduled status roll-up to a channel.

Sources: [Use lists](https://slack.com/help/articles/27452748828179-Use-Lists-in-Slack), [Track project tasks](https://slack.com/help/articles/27588021944339-Slack-lists--Track-project-tasks), [Automations](https://slack.com/help/articles/37752114318227-Set-up-automations-for-lists-in-Slack).

## 5. Interactive example — IT Support Requests

### 5.1 Run the working demo

Open **`Slack_Lists_Interactive_Demo.html`** in a browser. No server, installation, account or network connection is needed. It is a standalone educational prototype with in-browser local storage; **it is not Slack**.

### 5.2 What the prototype lets you do

1. Switch between **Table** and **Board**.
2. Filter records by **All**, **To Do**, **In Progress**, and **Done**.
3. Add a new task by typing a request name and selecting **Add**.
4. Change **Status** and **Priority** directly from the table or detail panel.
5. Open a task to edit **Assignee**, **Due Date**, and **Description**.
6. Add discussion **comments** to a selected task.
7. Add and check off **subtasks**.
8. View a small **activity history** of changes.
9. Search tasks by title, assignee, or description.
10. Reload to see demo data preserved in your own browser via `localStorage`, or use **Reset demo**.

**Prototype limits:** no real multi-user synchronization, access controls, Slack integration, outbound notifications, forms engine, or production database. Saved browser data is not backed up and may be cleared by browser settings. Board status change uses dropdowns rather than drag and drop.

### 5.3 Demo records

| Task | Priority | Status | Assignee | Due |
|---|---|---|---|---|
| VPN disconnects frequently | High | In Progress | Alex | 2026-11-13 |
| New employee laptop setup | Medium | To Do | Sam | 2026-11-16 |
| Network printer not responding | Low | Done | Alex | 2026-11-11 |
| Email access for new staff | High | To Do | Jordan | 2026-11-14 |

### 5.4 Expected interaction scenarios (acceptance checks)

- **Change status:** From table, set VPN to **Done** → it moves to Done in Board and stays there on reload.
- **Filter:** Set **To Do** → only records in that state remain visible.
- **Add item:** Create “Replace access point” → the task appears in To Do with default Medium priority.
- **Discuss:** Open an item, add “Waiting for vendor confirmation” → the comment appears in its item detail and persists locally.
- **Subtask:** Open laptop setup, add “Install security agent” → its checklist becomes available on the item.
- **Activity:** Changing the priority adds a timestamped activity entry.
- **Reset:** Select Reset demo to restore seeded task data.

### 5.5 Core state model used by prototype

```js
const item = {
  id: "task_1",
  name: "VPN disconnects frequently",
  status: "In Progress", // To Do | In Progress | Done
  priority: "High",       // Low | Medium | High
  assignee: "Alex",
  dueDate: "2026-11-13",
  description: "Investigate repeated disconnections.",
  comments: [{ id: "comment_1", text: "Checking client logs", createdAt: "..." }],
  subtasks: [{ id: "subtask_1", title: "Collect logs", done: false }],
  activity: [{ id: "event_1", description: "Status changed", createdAt: "..." }]
};
```

**Why a separate HTML file?** Markdown may *display* HTML snippets, but normal Markdown renderers intentionally do not execute arbitrary JavaScript. The companion HTML contains the live controls and source code. Do not paste JavaScript into a Markdown file expecting GitHub to run it.

## 6. Recommended product data model

Build a generic, reusable engine, not a one-off hardcoded help-desk table.

```text
Workspace
  ├── Lists
  │    ├── FieldDefinitions (name, type, choices, required, order)
  │    ├── Items (id, title, parentItemId, metadata)
  │    │    ├── FieldValues (itemId, fieldId, typed value)
  │    │    ├── Comments
  │    │    └── ActivityEvents
  │    ├── Views (layout, filters, sort, groupBy, visibility, defaults)
  │    ├── Members/Permissions
  │    └── Automations (trigger, predicate, actions)
  └── Users / Teams
```

**Design rules:**
- Store field definitions separately from row values. A user-added `Asset Tag` column should not require a new SQL column.
- Use stable IDs for lists, items, fields, views, comments, and user accounts.
- Enforce field types and selectable options on both the UI and server.
- Preserve references when renaming a field; define behavior for deleting fields and associated values.
- Use `parentItemId` for nested subtasks and guard against cycles.
- Treat saved views as a representation over the same item dataset, not separate copies.
- Protect all writes and reads with server-side permissions; UI-only restrictions are inadequate.
- Create durable events for notifications and audit logs, with idempotency for workflow retries.
- Support pagination and efficient filtering for large lists.

### Possible relational tables

`workspaces`, `workspace_members`, `lists`, `list_permissions`, `field_definitions`, `field_options`, `items`, `field_values`, `views`, `comments`, `activity_events`, `automation_rules`, `automation_runs`.

For typed custom values, either use validated JSON with indexes for frequently queried fields or a typed-value/EAV hybrid; benchmark filtering and sorting requirements first. This is an **implementation suggestion**, not a claim about Slack's private architecture.

## 7. Automation patterns to implement

| Trigger | Proposed action | Status |
|---|---|---|
| Form submitted | Create item with submitted answers | Slack documented |
| Field changes | Notify a user/channel | Slack documented |
| Upcoming or overdue due date | Send reminder to assignee | Slack documented |
| Scheduled summary | Send matching tasks to channel | Slack documented |
| Priority becomes High | Alert support lead | Proposed extension |
| Status becomes Done | Notify original requester | Proposed extension |
| Overdue beyond SLA | Escalate to team lead | Proposed extension |

Source: [Slack automation setup](https://slack.com/help/articles/37752114318227-Set-up-automations-for-lists-in-Slack).

## 8. Roadmap and implementation checklists

### Phase 1 — Foundation (P0)
- [ ] Create, rename, archive, and delete lists
- [ ] Schema and UI for typed custom fields
- [ ] Add/edit/delete/archive items
- [ ] Nested subtasks and inline editing
- [ ] Table layout
- [ ] Board layout; group by status/select field
- [ ] Filter, search, sorting, grouping, hidden fields
- [ ] Server validation and database migrations
- [ ] Unit/integration tests for field and item operations

### Phase 2 — Collaboration (P1)
- [ ] User assignment
- [ ] List membership and view/edit permissions
- [ ] Item discussions, mentions
- [ ] Saved and default views
- [ ] Activity feed and audit history
- [ ] Notifications/subscriptions
- [ ] Message-to-item integration when applicable
- [ ] Authorization and concurrency tests

### Phase 3 — Workflow extensions (P2)
- [ ] Dynamic intake forms from field definitions
- [ ] Form submission → create item
- [ ] Event-driven workflow engine
- [ ] Field-change notifications
- [ ] Due-date reminders and summaries
- [ ] CSV import/export
- [ ] Reporting, templates, archive management
- [ ] Retries, deduplication, logs, schedule/timezone tests

## 9. Suggested requirements for production parity

1. **Data safety:** optimistic concurrency or conflict resolution for edits by multiple users; clear destructive-action confirmations.
2. **Access:** private/shared lists; read/edit/admin scopes, including item comments and automation effects.
3. **Usability:** keyboard-friendly table editing, accessible controls, mobile-responsive item detail, empty/loading/error states.
4. **Date correctness:** store date-only fields carefully; due-date reminder schedules must respect list/workspace timezone.
5. **Performance:** virtualize/paginate wide and long tables; index frequently queried fields.
6. **Testing:** verify table/board consistency, filtered counts, saved views, subtask editing, permissions, and history.
7. **Design/IP:** reproduce functional concepts but create distinct names, styles, icons, assets, and layout details.

## 10. What is confirmed vs proposed

**Confirmed by Slack documentation:** lists/items, subtasks, typed fields, table/board views, filters and sorting, saved views, assignments, sharing, per-item threads, message-to-item, CSV import/export, intake forms, field notifications, and due-date automations.

**Our proposal—not verified Slack parity:** generic relational data architecture, high-priority auto-escalation, SLA rules, advanced dashboards, fully searchable change history, the prototype's local-storage persistence, and its specific IT sample data.

## 11. Definition of done for a first usable version

A user can create a list, add typed fields, enter/edit items, create subtasks, switch between a table and grouped board, filter/sort the same underlying records, and return to the application with saved data intact. All changes must be secured and validated server-side. Collaboration and automation can follow in later releases.

---

**Sources last checked:** 2026-11-12. This document is independent research and a proposed implementation plan, not an official Slack specification.
